# CyberPress 部署说明

## 快速部署

1. 解压文件
```bash
tar -xzf cyberpress_*.tar.gz
cd cyberpress
```

2. 配置环境变量
```bash
# 后端
cp backend/.env.example backend/.env
# 编辑 backend/.env 配置数据库等

# 前端
cp frontend/.env.example frontend/.env.local
# 编辑 frontend/.env.local 配置 API 地址
```

3. 启动服务
```bash
# 使用 Docker Compose
docker-compose up -d

# 或手动启动
# 后端
cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000

# 前端
cd frontend
npm install
npm run build
npm start
```

4. 访问应用
- 前端: http://YOUR_IP:3000
- 后端 API: http://YOUR_IP:8000
- API 文档: http://YOUR_IP:8000/docs

## 端口说明

- 3000: 前端服务
- 8000: 后端 API
- 5432: PostgreSQL (如果使用 Docker)
- 6379: Redis (如果使用 Docker)

## 注意事项

- 确保防火墙开放相应端口
- 生产环境请修改默认密码
- 建议使用 HTTPS (需要配置 SSL 证书)
